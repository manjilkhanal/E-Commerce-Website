import { FrontRoutes } from "./routes/FrontRoutes"


function App() {
  return<FrontRoutes/>
}

export default App
