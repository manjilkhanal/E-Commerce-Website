import { useState } from "react"
import {FormInput, SubmitBtn} from "../../components"
import { inStorage, setInForm } from "../../lib"
import { Form } from "react-bootstrap"
import http from "../../http"
import { useNavigate } from "react-router-dom"
import { useDispatch } from "react-redux"
import {setUser} from "../../store"

export const Dashboard = () => {
    return <div className="col-12">
    <div className="row">
        <div className="col-12 mt-3 text-center text-uppercase">
            <h2>User Dashboard</h2>
        </div>
    </div>

    <main className="row">
        <div className="col-lg-8 col-md-10 col-sm-10 mx-auto bg-white py-3 mb-4">
            
        </div>

    </main>
</div>
}