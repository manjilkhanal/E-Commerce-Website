import { Error404 } from "./Error404";

export { Error404}